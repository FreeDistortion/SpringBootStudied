package com.playdata.erp.board;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.BodyBuilder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.UriUtils;
import org.springframework.web.util.WebUtils;

import com.playdata.erp.dto.BoardDTO;
import com.playdata.erp.dto.BoardFileDTO;

import jakarta.servlet.http.HttpSession;

@Controller
public class BoardController {

	BoardService service;
	FileUploadLogicService fileUploadService;

	public BoardController() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Autowired
	public BoardController(BoardService service, FileUploadLogicService fileUploadService) {
		super();
		this.service = service;
		this.fileUploadService = fileUploadService;
	}

	@GetMapping("/board/list")
	public String list(Model model, String category) {
		List<BoardDTO> boardlist = service.findByCategory(category);
		model.addAttribute("boardlist", boardlist);
		model.addAttribute("category", category);
		return "board/boardlist";
	}

	@GetMapping("/board/write")
	public String writePage() {

		return "board/board_write";
	}

	@PostMapping("/board/write")
	public String write(BoardDTO board, HttpSession session) throws IllegalStateException, IOException {
		List<MultipartFile> files = board.getFiles();
		List<BoardFileDTO> boardFileDTOList = fileUploadService.uploadFiles(files);
		service.insert(board, boardFileDTOList);
		return "redirect:/board/list?category=all";
	}

	@GetMapping("/board/read")
	public ModelAndView read(String board_no, String cmd) {
		ModelAndView mav = null;
		if (cmd.equals("view")) {
			mav = new ModelAndView("board/board_read");
		} else {
			mav = new ModelAndView("board/board_update");
		}

		BoardDTO b = service.getBoardInfo(board_no);
		List<BoardFileDTO> boardFileDTOList = service.getFileList(board_no);
		mav.addObject("board", b);
		mav.addObject("boardFileDTOList", boardFileDTOList);
		return mav;
	}

	@PostMapping("/board/update")
	public String update(BoardDTO board) {
		service.update(board);
		return "redirect:/board/list?category=all";
	}

	@GetMapping("/board/delete")
	public String delete(String board_no) {
		service.delete(board_no);
		return "redirect:/board/list?category=all";
	}

	@PostMapping("/board/search")
	public ModelAndView search(String search, String tag) {
		ModelAndView mav = new ModelAndView("board/search");
		List<BoardDTO> list = service.search(tag, search);
		System.out.println(list);
		mav.addObject("boardlist", list);
		return mav;
	}

	@GetMapping("/board/download/{id}/{board_no}/{boardFileorder}")
	public ResponseEntity<UrlResource> downloadFile(@PathVariable String id, @PathVariable String board_no,
			@PathVariable String boardFileorder) throws MalformedURLException {

		// BoardFileDTO에 download 할 file을 실제 object로 변환.
		// 1. File download를 위해 DB에 저장된 file 정보 가져오기.
		// -> 다른 정보가 필요 없는 경우, 원본 file name만 parameter에 넘겨서 작업 가능.
		BoardFileDTO selectedFileInfo = service.getFile(new BoardFileDTO(board_no, "", "", boardFileorder));

		// 2. BoardFileDTO에서 꺼낸 download file을 object로 변환
		// -> 변환을 위해 file의 실제 저장 위치 정보 넘기기.
		UrlResource resource = new UrlResource(
				"file:" + fileUploadService.getUploadPath(selectedFileInfo.getStoreFilename()));

		// 3. File name에 한글이 있는 경우, 오류가 발생하지 않도록 처리 - download file name
		String encodedFileName = UriUtils.encode(selectedFileInfo.getOriginalFilename(), "UTF-8");
		String myContentType = "attachment; filename=\"" + encodedFileName + "\"";

		// 4. Response message 만들기.
		/*
		 * BodyBuilder boduBuilder = ResponseEntity.ok(); ResponseEntity<UrlResource>
		 * response=boduBuilder.body(resource);
		 */
		// CONTENT_DISPOSITION을 통해 browser에서 download 가능하도록 설정.
		return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, myContentType).body(resource);
	}
}
