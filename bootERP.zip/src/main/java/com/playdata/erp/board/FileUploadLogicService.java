package com.playdata.erp.board;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.playdata.erp.dto.BoardFileDTO;

@Service
public class FileUploadLogicService {
	
	// 설정 file에 정의된 property를 가져온 후 설정한 경로에 file upload가 되도록 수정
	@Value("${file.dir}")
	private String uploadpath;

	// file name을 던달 받아 path 와 연결 후 return
	public String getUploadPath(String filename) {
		return uploadpath+filename;
	}
	
	
	
	// file upload execution method
	// upload한 file이 곧 DB에 저장할 정보
	// uploaded file의 정보를 이용해 DTO를 만들고 ArrayList에 담아서 return.
	public ArrayList<BoardFileDTO> uploadFiles(List<MultipartFile> multipartFiles) throws IllegalStateException, IOException {
		ArrayList<BoardFileDTO> fileDTOList=new ArrayList<BoardFileDTO>();
		int count=1;
		for (MultipartFile file : multipartFiles) {
			if (!file.isEmpty()) {
				// Upload를 하는 경우 original file name과 server에 저장되는 server단에서 식별 가능한 file name 두
				// 개를 관리.
				String originalFileName = file.getOriginalFilename();
				String storageFileName = createStorageFileName(originalFileName);
				System.out.println(originalFileName + ", " + storageFileName);

				// File name과 path를 이용해 실제 file object를 만들고 upload하기.
				System.out.println(getUploadPath(storageFileName));
				file.transferTo(new File(getUploadPath(storageFileName)));
				fileDTOList.add(new BoardFileDTO(null, originalFileName, storageFileName,""+(count++)));
			}
		}
		
		return fileDTOList;
	}

	// method return file name to identify
	private String createStorageFileName(String originalFileName) {
		int position = originalFileName.lastIndexOf(".");
		String ext = originalFileName.substring(position + 1);
		String uuid = UUID.randomUUID().toString();
		return uuid + "." + ext;
	}
}
