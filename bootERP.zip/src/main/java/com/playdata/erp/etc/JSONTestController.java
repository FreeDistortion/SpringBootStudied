package com.playdata.erp.etc;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.playdata.erp.board.BoardService;
import com.playdata.erp.dto.BoardDTO;

@Controller
@RequestMapping("/json")
public class JSONTestController {
	
	BoardService service;

	@Autowired
	public JSONTestController(BoardService service) {
		super();
		this.service = service;
	}
	
	@ResponseBody
	@GetMapping("/getJsonObj")
	public BoardDTO responseObj() {
		
		return service.getBoardInfo("20");
	}
	
	@ResponseBody
	@GetMapping("/getJsonArr")
	public List<BoardDTO> responseJsonArr() {
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return service.boardList();
	}
}
