package com.playdata.erp.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

// @Configuration 선언 후 WebMvcConfigurer 상속

@Configuration
public class MyWebConfig implements WebMvcConfigurer {

	// static resource를 설정하는 경우
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		// 특정 path(/download)로 요청하면 실제 file이 저장된 위치를 연결해서 resource를 가져올 수 있도록 처리
//		ResourceHandlerRegistration o =registry.addResourceHandler("/download/**");
//		o.addResourceLocations("file:///C:/Users/Playdata/git/upload/");
		registry.addResourceHandler("/download/**").addResourceLocations("file:///C:/Users/Playdata/git/upload/");
	}

}
