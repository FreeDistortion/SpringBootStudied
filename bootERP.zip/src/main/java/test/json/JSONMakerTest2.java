package test.json;

import java.io.FileWriter;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class JSONMakerTest2 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		JSONObject jsonObject= new JSONObject();
		
		//
		jsonObject.put("name", "김서연");

		//
		jsonObject.put("age", "25");
		
		//
		JSONArray ja1= new JSONArray();
		ja1.add("자바");
		ja1.add("하둡");
		ja1.add("시큐어코딩");
		
		jsonObject.put("subject", ja1);
		
		//
		JSONObject joio1 = new JSONObject();
		joio1.put("zip", "111-222");
		joio1.put("addr1", "인천시");
		
		jsonObject.put("addr",joio1);
		
		//
		JSONArray ja2=new JSONArray();
		JSONObject joia1=new JSONObject();
		joia1.put("subject", "java");
		joia1.put("month", "11");
		ja2.add(joia1);
		
		JSONObject joia2=new JSONObject();
		joia2.put("subject", "servlet");
		joia2.put("month", "12");
		ja2.add(joia2);
		
		jsonObject.put("history", ja2);
		
		
		FileWriter fw = new FileWriter("src/main/java/test/json/myjson2.json");
		fw.write(jsonObject.toJSONString());
		fw.flush();
		fw.close();
		
	}

}
