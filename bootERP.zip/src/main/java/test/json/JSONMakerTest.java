package test.json;
// JSON data 만들기

import java.io.FileWriter;
import java.io.IOException;

/*
 * {} -> JSON object => JSONObject(Map structure)
 * [] -> JSON array => JSONArray(List structure)
 */

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class JSONMakerTest {

	public static void main(String[] args) throws IOException {
		JSONObject myjson = new JSONObject();
		myjson.put("name", "BTS");
		myjson.put("age", "30");

		JSONArray subjectlist = new JSONArray();
		subjectlist.add("java");
		subjectlist.add("spring");
		subjectlist.add("hadoop");

		// 상기 작성한 JSONArray를 JSONObject에 추가
		myjson.put("subject", subjectlist);

		JSONArray commentlist = new JSONArray();
		JSONObject comment1 = new JSONObject();
		comment1.put("no", "1");
		comment1.put("content", "Make JSON");
		comment1.put("id", "bts1");
		
		JSONObject comment2 = new JSONObject();
		comment1.put("no", "2");
		comment1.put("content", "Make JSON file either");
		comment1.put("id", "bts2");
		
		commentlist.add(comment1);
		commentlist.add(comment2);
		
		myjson.put("comment", commentlist);
		
		System.out.println(myjson.toJSONString());
		
		
		FileWriter fw = new FileWriter("src/main/java/test/json/myjson2.json");
		fw.write(myjson.toJSONString());
		fw.flush();
		fw.close();
	}

}
