package test.json;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class JSONParserExam {

	public static void main(String[] args) throws FileNotFoundException, IOException, ParseException {
		// TODO Auto-generated method stub
		JSONParser p = new JSONParser();
		JSONObject rt = (JSONObject) p.parse(new FileReader("src/main/java/test/json/myjson2.json"));
		StringBuilder sb = new StringBuilder();
		
		//
		String name = (String) rt.get("name");
		sb.append(name);
		sb.append("\n");
		
		//
		String age = (String) rt.get("age");
		sb.append(age);
		sb.append("\n");
		
		//
		JSONArray sbjlist = (JSONArray) rt.get("subject");
		for (int i = 0; i < sbjlist.size(); i++) {
			String s = (String) sbjlist.get(i);
			sb.append(s+" ");
		}
		sb.append("\n");
		
		//
		JSONArray hstylist = (JSONArray) rt.get("history");
		for (int i = 0; i < hstylist.size(); i++) {
			JSONObject h = (JSONObject) hstylist.get(i);
			sb.append(h.get("subject") + " ");
			sb.append(h.get("month"));
			sb.append("\n");
		}
		
		System.out.println(sb);
	}

}
